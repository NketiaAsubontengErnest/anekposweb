Questions should be asked on the forum:
https://groups.google.com/d/forum/phpdesktop
